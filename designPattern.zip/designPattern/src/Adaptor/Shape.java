package Adaptor;

public interface Shape {
    void draw(int x, int y, int z, int j);
}
