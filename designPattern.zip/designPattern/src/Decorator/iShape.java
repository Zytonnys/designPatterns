package Decorator;

public interface iShape {
    void drawShape();
}
