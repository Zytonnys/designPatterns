package Bridge;

public interface iShape_bridge {
    void ShpeType_iShape();
    void ShpeColor_iShape();
}
